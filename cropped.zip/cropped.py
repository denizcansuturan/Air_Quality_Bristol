import pandas as pd
import numpy as np

# Set Pandas display options
pd.set_option('display.max_columns', None)  # Show all columns
pd.set_option('display.width', None)        # Allow display to use full width
pd.set_option('display.max_rows', None)
pd.set_option('display.expand_frame_repr', False)


# load and explore the dataset to start the analysis
df_ = pd.read_csv('data/Air_Quality_Continuous.csv')
df = df_.copy()

df.head()

df.info() # date time column is an object

df['ObjectId'].notna().sum() # this is equal to zero which means there is no data in this column and this column
# does not give any information.

unique_count = df['ObjectId2'].nunique()
unique_count == len(df['ObjectId2']) # this says true. so this column acts as an index number, but it is starting from 1.
df['ObjectId2'].head()
# 0    1
# 1    2
# 2    3
# 3    4
# 4    5

df['ObjectId2'].tail()

# 1603487    1603488
# 1603488    1603489
# 1603489    1603490
# 1603490    1603491
# 1603491    1603492

df["Date_Time"].head() # see how the date is stored
df['Date_Time'] = pd.to_datetime(df['Date_Time'], format='%Y/%m/%d %H:%M:%S+00', errors='coerce')
# makes NaT if a date doesn't represent date


# i) Crop the data to hold after the first 1st January 2015 record.
cropped_dataset = df[df['Date_Time'] >= '2015-01-01']
cropped_dataset.to_csv("TASK3/cropped_dataset.csv", index=False)


# to check
max_date = cropped_dataset['Date_Time'].max()
min_date = cropped_dataset['Date_Time'].min()


# ii) Cleanse the data

cropped_dataset.isnull().any()
cropped_dataset["Site_ID"].unique()
cropped_dataset["Site_ID"].isnull().sum()

# drop observations with null Site_ID values since it doesn't give any info.
cleansed_dataset = cropped_dataset.dropna(subset=['Site_ID'])

# so columns other than Date time, siteID, ObjectId, ObjectId2 and temperature shouldn't have negative values by nature
# since they represent concentrations, air pressure and relative humidity.

columns_to_exclude = ['Date_Time', 'Site_ID', 'ObjectId', 'ObjectId2', 'Temperature']
interested_columns = list(set(cleansed_dataset.columns) - set(columns_to_exclude))
# Check if any value in the interested columns is negative
negative_values_mask = (cleansed_dataset[interested_columns] < 0).any(axis=1)
negative_values_mask.head()

# Drop rows with negative values

cleansed_dataset = cleansed_dataset[~negative_values_mask]
cleansed_dataset[interested_columns].describe() # to check minimum values
# Count the number of duplicated rows

cleansed_dataset = cleansed_dataset.drop_duplicates(subset=['Date_Time', 'Site_ID'], keep='last')

cleansed_dataset.shape
cleansed_dataset.info()

cleansed_dataset.to_csv("TASK3/cleansed_dataset.csv", index=False)

